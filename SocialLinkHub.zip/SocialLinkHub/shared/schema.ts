import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User Profile Schema
export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  bio: text("bio"),
  imageUrl: text("image_url"),
  location: text("location"),
});

export const insertUserProfileSchema = createInsertSchema(userProfiles).pick({
  name: true,
  bio: true,
  imageUrl: true,
  location: true,
});

// Social Links Schema
export const socialLinks = pgTable("social_links", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  platform: text("platform").notNull(),
  url: text("url").notNull(),
  username: text("username"),
  clickCount: integer("click_count").default(0),
  order: integer("order").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSocialLinkSchema = createInsertSchema(socialLinks).pick({
  title: true,
  platform: true,
  url: true,
  username: true,
  order: true,
  isActive: true,
});

// Click Analytics Schema
export const clickAnalytics = pgTable("click_analytics", {
  id: serial("id").primaryKey(),
  linkId: integer("link_id").notNull(),
  clickedAt: timestamp("clicked_at").defaultNow(),
  userAgent: text("user_agent"),
  referrer: text("referrer"),
});

export const insertClickAnalyticsSchema = createInsertSchema(clickAnalytics).pick({
  linkId: true,
  userAgent: true,
  referrer: true,
});

// Type Exports
export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;

export type SocialLink = typeof socialLinks.$inferSelect;
export type InsertSocialLink = z.infer<typeof insertSocialLinkSchema>;

export type ClickAnalytic = typeof clickAnalytics.$inferSelect;
export type InsertClickAnalytic = z.infer<typeof insertClickAnalyticsSchema>;
