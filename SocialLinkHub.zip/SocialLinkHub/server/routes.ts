import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSocialLinkSchema, insertUserProfileSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  const router = express.Router();

  // Get user profile
  router.get("/api/profile", async (req: Request, res: Response) => {
    try {
      const profile = await storage.getUserProfile();
      if (!profile) {
        // Return default profile if none exists
        return res.json(await storage.createDefaultUserProfile());
      }
      return res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      return res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  // Update user profile
  router.put("/api/profile", async (req: Request, res: Response) => {
    try {
      const profileData = insertUserProfileSchema.parse(req.body);
      const profile = await storage.updateUserProfile(profileData);
      return res.json(profile);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Get all social links
  router.get("/api/links", async (req: Request, res: Response) => {
    try {
      const links = await storage.getAllLinks();
      // If no links exist yet, create default ones
      if (links.length === 0) {
        return res.json(await storage.createDefaultLinks());
      }
      return res.json(links);
    } catch (error) {
      console.error("Error fetching links:", error);
      return res.status(500).json({ message: "Failed to fetch links" });
    }
  });

  // Create new social link
  router.post("/api/links", async (req: Request, res: Response) => {
    try {
      const linkData = insertSocialLinkSchema.parse(req.body);
      const link = await storage.createLink(linkData);
      return res.status(201).json(link);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: "Failed to create link" });
    }
  });

  // Update a social link
  router.put("/api/links/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const linkData = insertSocialLinkSchema.parse(req.body);
      const link = await storage.updateLink(id, linkData);
      
      if (!link) {
        return res.status(404).json({ message: "Link not found" });
      }
      
      return res.json(link);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      return res.status(500).json({ message: "Failed to update link" });
    }
  });

  // Delete a social link
  router.delete("/api/links/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteLink(id);
      
      if (!success) {
        return res.status(404).json({ message: "Link not found" });
      }
      
      return res.status(204).send();
    } catch (error) {
      console.error("Error deleting link:", error);
      return res.status(500).json({ message: "Failed to delete link" });
    }
  });

  // Track link click
  router.post("/api/links/:id/click", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const userAgent = req.headers["user-agent"] || "";
      const referrer = req.headers.referer || "";
      
      const analytics = await storage.trackLinkClick(id, {
        linkId: id,
        userAgent,
        referrer,
      });
      
      return res.status(200).json(analytics);
    } catch (error) {
      console.error("Error tracking link click:", error);
      return res.status(500).json({ message: "Failed to track link click" });
    }
  });

  // Get click analytics
  router.get("/api/analytics", async (req: Request, res: Response) => {
    try {
      const analytics = await storage.getLinkAnalytics();
      return res.json(analytics);
    } catch (error) {
      console.error("Error fetching analytics:", error);
      return res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  app.use(router);

  const httpServer = createServer(app);
  return httpServer;
}
