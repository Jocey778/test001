import {
  UserProfile, SocialLink, ClickAnalytic,
  InsertUserProfile, InsertSocialLink, InsertClickAnalytic,
  userProfiles, socialLinks, clickAnalytics
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User Profile methods
  getUserProfile(): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  createDefaultUserProfile(): Promise<UserProfile>;
  
  // Social Links methods
  getAllLinks(): Promise<SocialLink[]>;
  getLink(id: number): Promise<SocialLink | undefined>;
  createLink(link: InsertSocialLink): Promise<SocialLink>;
  updateLink(id: number, link: InsertSocialLink): Promise<SocialLink | undefined>;
  deleteLink(id: number): Promise<boolean>;
  createDefaultLinks(): Promise<SocialLink[]>;
  
  // Analytics methods
  trackLinkClick(id: number, analytics: InsertClickAnalytic): Promise<SocialLink>;
  getLinkAnalytics(): Promise<{ linkId: number, title: string, platform: string, clicks: number }[]>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private profile: UserProfile | undefined;
  private links: Map<number, SocialLink>;
  private analytics: ClickAnalytic[];
  private currentLinkId: number;

  constructor() {
    this.links = new Map();
    this.analytics = [];
    this.currentLinkId = 1;
  }

  // User Profile methods
  async getUserProfile(): Promise<UserProfile | undefined> {
    return this.profile;
  }

  async createUserProfile(profileData: InsertUserProfile): Promise<UserProfile> {
    const newProfile: UserProfile = {
      id: 1,
      name: profileData.name,
      bio: profileData.bio || null,
      imageUrl: profileData.imageUrl || null,
      location: profileData.location || null,
    };
    this.profile = newProfile;
    return newProfile;
  }

  async updateUserProfile(profileData: InsertUserProfile): Promise<UserProfile> {
    if (!this.profile) {
      return this.createUserProfile(profileData);
    }
    
    const updatedProfile: UserProfile = {
      ...this.profile,
      ...profileData,
    };
    
    this.profile = updatedProfile;
    return updatedProfile;
  }

  async createDefaultUserProfile(): Promise<UserProfile> {
    const defaultProfile: InsertUserProfile = {
      name: "Narawit Petsuwan",
      bio: "Just a small 3d Artist do thing when I'm boring",
      imageUrl: "https://scontent.furt1-1.fna.fbcdn.net/v/t39.30808-1/458379067_122102569184504718_6890255651484613217_n.jpg?stp=dst-jpg_s200x200_tt6&_nc_cat=103&ccb=1-7&_nc_sid=2d3e12&_nc_eui2=AeEichEvQSSem1B7s__cmF5JPmqjQem59pA-aqNB6bn2kDmfGPrujsgiqixV9Fta22fbS8z86YBz-OBYXn12ROuX&_nc_ohc=5DEOzKyQ-S8Q7kNvgG7ZK2T&_nc_oc=AdmmP0lrGaEbWDSwjjLy9kW-s3tqW75VLPdvxjZwGv9EI5BGdqyeXTQkpz9iVSN2WJM&_nc_zt=24&_nc_ht=scontent.furt1-1.fna&_nc_gid=KxS6dpZ4NeNaa8ZvDLhqug&oh=00_AYE8pzAYVuRTHyDeXeyBkpMDSn4kJZgraDx93ik9rW9QMg&oe=67E00B7D",
      location: "Thailand, BKK",
    };
    
    return this.createUserProfile(defaultProfile);
  }

  // Social Links methods
  async getAllLinks(): Promise<SocialLink[]> {
    const links = Array.from(this.links.values());
    return links
      .filter(link => link.isActive)
      .sort((a, b) => a.order - b.order);
  }

  async getLink(id: number): Promise<SocialLink | undefined> {
    return this.links.get(id);
  }

  async createLink(linkData: InsertSocialLink): Promise<SocialLink> {
    const id = this.currentLinkId++;
    const now = new Date();
    
    const newLink: SocialLink = {
      id,
      title: linkData.title,
      platform: linkData.platform,
      url: linkData.url,
      username: linkData.username || null,
      order: linkData.order,
      isActive: linkData.isActive ?? true,
      clickCount: 0,
      createdAt: now,
    };
    
    this.links.set(id, newLink);
    return newLink;
  }

  async updateLink(id: number, linkData: InsertSocialLink): Promise<SocialLink | undefined> {
    const existingLink = this.links.get(id);
    
    if (!existingLink) {
      return undefined;
    }
    
    const updatedLink: SocialLink = {
      ...existingLink,
      ...linkData,
    };
    
    this.links.set(id, updatedLink);
    return updatedLink;
  }

  async deleteLink(id: number): Promise<boolean> {
    if (!this.links.has(id)) {
      return false;
    }
    
    // Instead of deleting, mark as inactive
    const link = this.links.get(id)!;
    link.isActive = false;
    this.links.set(id, link);
    
    return true;
  }

  async createDefaultLinks(): Promise<SocialLink[]> {
    const defaultLinks: InsertSocialLink[] = [
      {
        title: "Patreon",
        platform: "patreon",
        url: "https://www.patreon.com/c/JOCEY778",
        username: "JOCEY778",
        order: 1,
        isActive: true,
      },
      {
        title: "Twitter",
        platform: "twitter",
        url: "https://twitter.com/narawit",
        username: "@narawit",
        order: 2,
        isActive: true,
      },
      {
        title: "LinkedIn",
        platform: "linkedin",
        url: "https://www.linkedin.com/in/narawit",
        username: "Narawit Petsuwan",
        order: 3,
        isActive: true,
      },
      {
        title: "YouTube",
        platform: "youtube",
        url: "https://www.youtube.com/@Jocey.778",
        username: "Jocey.778",
        order: 4,
        isActive: true,
      },
      {
        title: "Facebook",
        platform: "facebook",
        url: "https://www.facebook.com/profile.php?id=61565141557522",
        username: "Narawit Petsuwan",
        order: 5,
        isActive: true,
      },
      {
        title: "GitHub",
        platform: "github",
        url: "https://github.com/Jocey778",
        username: "Jocey778",
        order: 6,
        isActive: true,
      },
      {
        title: "Personal Website",
        platform: "website",
        url: "https://www.narawit.com",
        username: "www.narawit.com",
        order: 7,
        isActive: true,
      },
    ];
    
    const createdLinks: SocialLink[] = [];
    
    for (const linkData of defaultLinks) {
      const link = await this.createLink(linkData);
      createdLinks.push(link);
    }
    
    return createdLinks;
  }

  // Analytics methods
  async trackLinkClick(id: number, analyticsData: InsertClickAnalytic): Promise<SocialLink> {
    const link = this.links.get(id);
    
    if (!link) {
      throw new Error(`Link with ID ${id} not found`);
    }
    
    // Create analytics entry
    const now = new Date();
    const clickAnalytic: ClickAnalytic = {
      id: this.analytics.length + 1,
      linkId: analyticsData.linkId,
      userAgent: analyticsData.userAgent || null,
      referrer: analyticsData.referrer || null,
      clickedAt: now,
    };
    
    this.analytics.push(clickAnalytic);
    
    // Update link click count
    link.clickCount = (link.clickCount || 0) + 1;
    this.links.set(id, link);
    
    return link;
  }

  async getLinkAnalytics(): Promise<{ linkId: number, title: string, platform: string, clicks: number }[]> {
    const result: { linkId: number, title: string, platform: string, clicks: number }[] = [];
    
    // Using Array.from to avoid issues with iterators
    const links = Array.from(this.links.values());
    
    for (const link of links) {
      if (link.isActive) {
        result.push({
          linkId: link.id,
          title: link.title,
          platform: link.platform,
          clicks: link.clickCount || 0,
        });
      }
    }
    
    return result.sort((a, b) => b.clicks - a.clicks);
  }
}

// Create and export storage instance
export const storage = new MemStorage();
