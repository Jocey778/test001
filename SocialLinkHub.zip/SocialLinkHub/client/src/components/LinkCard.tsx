import { SocialLink } from "@shared/schema";
import { motion } from "framer-motion";
import { 
  FaTwitter, FaInstagram, FaLinkedin, FaYoutube, 
  FaGithub, FaTiktok, FaFacebook, FaPinterest, 
  FaTwitch, FaMedium, FaDribbble, FaBehance,
  FaGlobe, FaEnvelope, FaLink, FaChevronRight 
} from "react-icons/fa";

interface LinkCardProps {
  link: SocialLink;
  onClick: () => void;
}

// Map of platform names to their corresponding icons
const platformIcons: Record<string, JSX.Element> = {
  twitter: <FaTwitter />,
  instagram: <FaInstagram />,
  linkedin: <FaLinkedin />,
  youtube: <FaYoutube />,
  github: <FaGithub />,
  tiktok: <FaTiktok />,
  facebook: <FaFacebook />,
  pinterest: <FaPinterest />,
  twitch: <FaTwitch />,
  medium: <FaMedium />,
  dribbble: <FaDribbble />,
  behance: <FaBehance />,
  website: <FaGlobe />,
  email: <FaEnvelope />,
};

const LinkCard = ({ link, onClick }: LinkCardProps) => {
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  // Get the appropriate icon or use a default
  const icon = platformIcons[link.platform.toLowerCase()] || <FaLink />;

  return (
    <motion.a
      href={link.url}
      target="_blank"
      rel="noopener noreferrer"
      className="bg-white rounded-xl p-4 flex items-center shadow-md w-full hover:shadow-lg"
      variants={item}
      whileHover={{ y: -3, transition: { duration: 0.2 } }}
      whileTap={{ scale: 0.98 }}
      onClick={(e) => {
        // We're still navigating to the link, but we want to track the click
        onClick();
      }}
    >
      <div className="w-10 h-10 rounded-full bg-gradient-to-r from-primary to-accent flex items-center justify-center flex-shrink-0 text-white">
        {icon}
      </div>
      <div className="ml-4 flex-grow">
        <h3 className="font-medium">{link.title}</h3>
        <p className="text-sm text-gray-500">{link.username}</p>
      </div>
      <div className="text-gray-400">
        <FaChevronRight />
      </div>
    </motion.a>
  );
};

export default LinkCard;
