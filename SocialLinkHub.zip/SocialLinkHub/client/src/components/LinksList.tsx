import { SocialLink } from "@shared/schema";
import LinkCard from "./LinkCard";
import { motion } from "framer-motion";

interface LinksListProps {
  links: SocialLink[];
  onLinkClick: (linkId: string) => void;
}

const LinksList = ({ links, onLinkClick }: LinksListProps) => {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <motion.div 
      className="space-y-4 mt-8"
      variants={container}
      initial="hidden"
      animate="show"
    >
      {links.map((link) => (
        <LinkCard 
          key={link.id} 
          link={link} 
          onClick={() => onLinkClick(link.id)}
        />
      ))}
    </motion.div>
  );
};

export default LinksList;
