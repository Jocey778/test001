import { UserProfile } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { motion } from "framer-motion";

interface ProfileSectionProps {
  profile: UserProfile;
}

const ProfileSection = ({ profile }: ProfileSectionProps) => {
  return (
    <motion.div 
      className="flex flex-col items-center mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {/* Profile Image */}
      <motion.div 
        className="mb-4"
        whileHover={{ scale: 1.05 }}
        transition={{ duration: 0.3 }}
      >
        <Avatar className="w-32 h-32 border-4 border-white shadow-lg">
          <AvatarImage src={profile.imageUrl} alt={profile.name} />
          <AvatarFallback className="bg-gradient-to-r from-primary to-secondary text-white text-2xl">
            {profile.name.split(' ').map(n => n[0]).join('')}
          </AvatarFallback>
        </Avatar>
      </motion.div>
      
      {/* Profile Name */}
      <motion.h1 
        className="text-2xl font-semibold text-white mb-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        {profile.name}
      </motion.h1>
      
      {/* Profile Bio */}
      <motion.p 
        className="text-white text-center text-opacity-90 mb-4 max-w-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.5 }}
      >
        {profile.bio}
      </motion.p>
      
      {/* Profile Location */}
      {profile.location && (
        <motion.div 
          className="flex items-center text-white text-opacity-80 text-sm mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-4 w-4 mr-2"
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" 
            />
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" 
            />
          </svg>
          <span>{profile.location}</span>
        </motion.div>
      )}
    </motion.div>
  );
};

export default ProfileSection;
