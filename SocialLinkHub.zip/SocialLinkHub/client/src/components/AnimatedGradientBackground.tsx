import { ReactNode } from "react";
import { motion } from "framer-motion";

interface AnimatedGradientBackgroundProps {
  children: ReactNode;
}

const AnimatedGradientBackground = ({ children }: AnimatedGradientBackgroundProps) => {
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Animated gradient background */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-primary via-secondary to-accent"
        animate={{
          background: [
            "linear-gradient(-45deg, hsl(var(--primary)), hsl(var(--secondary)), hsl(var(--accent)), hsl(var(--primary)))",
            "linear-gradient(-45deg, hsl(var(--secondary)), hsl(var(--accent)), hsl(var(--primary)), hsl(var(--secondary)))",
            "linear-gradient(-45deg, hsl(var(--accent)), hsl(var(--primary)), hsl(var(--secondary)), hsl(var(--accent)))",
            "linear-gradient(-45deg, hsl(var(--primary)), hsl(var(--secondary)), hsl(var(--accent)), hsl(var(--primary)))",
          ],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "linear",
        }}
      />

      {/* Content overlay */}
      <div className="relative z-10 flex-grow flex flex-col">
        {children}
      </div>
    </div>
  );
};

export default AnimatedGradientBackground;
