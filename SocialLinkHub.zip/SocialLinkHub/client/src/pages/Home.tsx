import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import ProfileSection from "@/components/ProfileSection";
import LinksList from "@/components/LinksList";
import AnimatedGradientBackground from "@/components/AnimatedGradientBackground";
import { UserProfile, SocialLink } from "@shared/schema";

const Home = () => {
  // Fetch user profile data
  const { data: profile, isLoading: profileLoading } = useQuery<UserProfile>({
    queryKey: ["/api/profile"],
  });

  // Fetch social links
  const { data: links, isLoading: linksLoading } = useQuery<SocialLink[]>({
    queryKey: ["/api/links"],
  });

  // Track link clicks
  const trackClickMutation = useMutation({
    mutationFn: (linkId: string) => 
      apiRequest("POST", `/api/links/${linkId}/click`, {}),
    onSuccess: () => {
      // Invalidate links query to refresh click counts
      queryClient.invalidateQueries({ queryKey: ["/api/links"] });
    },
  });

  const handleLinkClick = (linkId: string) => {
    trackClickMutation.mutate(linkId);
  };

  return (
    <AnimatedGradientBackground>
      <div className="container mx-auto px-4 py-8 max-w-md">
        {profileLoading ? (
          <div className="flex flex-col items-center space-y-4 animate-pulse">
            <div className="w-32 h-32 bg-white/20 rounded-full"></div>
            <div className="h-6 bg-white/20 rounded w-1/2"></div>
            <div className="h-4 bg-white/20 rounded w-3/4"></div>
          </div>
        ) : profile ? (
          <ProfileSection profile={profile} />
        ) : (
          <div className="text-white text-center">Profile not found</div>
        )}

        {linksLoading ? (
          <div className="space-y-4 mt-8">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-16 bg-white/20 rounded-xl animate-pulse"></div>
            ))}
          </div>
        ) : links ? (
          <LinksList links={links} onLinkClick={handleLinkClick} />
        ) : (
          <div className="text-white text-center mt-8">No links found</div>
        )}

        {/* Footer */}
        <div className="mt-8 text-center text-white text-opacity-80 text-sm">
          <p>© {new Date().getFullYear()} • Link in Bio</p>
        </div>
      </div>
    </AnimatedGradientBackground>
  );
};

export default Home;
